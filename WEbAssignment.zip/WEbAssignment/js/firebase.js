 // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDQJKbVvF6Wl7NYeiSWcuhrpnBFo5Qkf-w",
    authDomain: "webassignment666.firebaseapp.com",
    databaseURL: "https://webassignment666.firebaseio.com",
    projectId: "webassignment666",
    storageBucket: "webassignment666.appspot.com",
    messagingSenderId: "224824077875"
  };
  firebase.initializeApp(config);
